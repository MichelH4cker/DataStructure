#ifndef __FILE_H__
#define __FILE_H__

#include "main.h"

struct Node;
struct Data;

void readAndStorageFile(struct Node **root_ref);


#endif