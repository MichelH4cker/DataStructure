#ifndef __COMMANDS_H__
#define __COMMANDS_H__

#include "main.h"

struct Node;
struct Data;

void remoteController(struct Node **root_ref, int id);


#endif